# KeywordAnalysis
Study several keywords appearances on the 2 target sites

# Download Chrome from Google
[Chrome Web Browser](https://dl.google.com/tag/s/appguid%3D%7B8A69D345-D564-463C-AFF1-A69D9E530F96%7D%26iid%3D%7B1109710B-86F9-01FD-F08A-73F0D3F0D7E5%7D%26lang%3Den%26browser%3D4%26usagestats%3D1%26appname%3DGoogle%2520Chrome%26needsadmin%3Dprefers%26ap%3Dx64-stable-statsdef_1%26installdataindex%3Ddefaultbrowser/update2/installers/ChromeSetup.exe)

# Install Requirements
pip3 install -r requirements.txt

# Run
python3 run.py

# Example Input
* URLs
`https://timesofindia.indiatimes.com/india/would-you-mind-saying-sorry-for-note-ban-prakash-raj-to-pm-modi/articleshow/61565057.cms;https://timesofindia.indiatimes.com/videos/news/with-one-sarcastic-tweet-owaisi-nails-bjp-congress-on-their-hypocrisy/videoshow/61859286.cms`
* Keywords
`Narendra Modi;one`